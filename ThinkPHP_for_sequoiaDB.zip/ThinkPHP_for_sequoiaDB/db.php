<?php return array (
  'DB_TYPE' => 'sequoia',
  'DB_HOST' => '',
  'DB_NAME' => '',
  'DB_USER' => '',
  'DB_PWD' => '',
  'DB_PORT' => '',
  'DB_PREFIX' => '',
  'DB_CHARSET' => 'utf8',
  'DB_DEBUG' => true,
);

